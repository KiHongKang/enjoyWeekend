console.log(Math.round(1.4));
console.log(Math.round(1.6));


console.log("");

function calcplus(first, second){

  console.log(first + second);

}

function calmul(f, s){
console.log(f*s);
}

console.log(calcplus(3,4));
console.log(calmul(5,6));
