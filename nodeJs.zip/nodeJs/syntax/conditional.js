var args = process.argv;
console.log(args);
if(args[2] === '1'){
  console.log('a3');

}else{
  console.log('error');
}
