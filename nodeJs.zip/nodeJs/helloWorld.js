console.log(1+1);
console.log(1*3);
console.log(3/6);
console.log(3-1);

console.log('1' + '1');
console.log('j             '.length);


// console.log('ㄴㅇ라ㅓㄴ아러ㅏ닝러ㅏㅇ러ㅏㅁrkskskskskskdfslkfjklfjkljflwkejflkwejfkwlefj
// \sfksdjfksdjfkldsjfdskjfksdfjkdslf
// ');

//
var name ='ki hong';
var letter=`Dear ${name}
${1+1}


akjdsfjksdjflk`;

console.log(letter);

// console.log(letter);
// var name = 'k8805';
// String literals
// var letter = 'Dear '+name+'\
// \Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. '+name+' Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa egoing qui officia deserunt mollit anim id est laborum. '+name;
// //
// // // Template literals
// var letter = `Dear ${name}
//
// Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ${name} Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ${1+1} Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa egoing qui officia deserunt mollit anim id est laborum. ${name}`;
